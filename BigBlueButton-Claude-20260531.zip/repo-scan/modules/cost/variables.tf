variable "project_name" {
  description = "Project name for resource naming"
  type        = string
}

variable "environment" {
  description = "Environment name"
  type        = string
}

variable "aws_region" {
  description = "AWS region"
  type        = string
}

variable "alert_email" {
  description = "Email address for budget alerts"
  type        = string
}

variable "monthly_budget_alert_threshold" {
  description = "Monthly budget alert threshold in USD (sends warning email)"
  type        = number
  default     = 100
}

variable "monthly_budget_limit" {
  description = "Monthly budget hard limit in USD (triggers resource shutdown)"
  type        = number
  default     = 250
}

variable "ec2_instance_id" {
  description = "EC2 instance ID to stop when budget limit is reached"
  type        = string
}

variable "enable_auto_stop" {
  description = "Enable automatic EC2 shutdown when budget limit is reached"
  type        = bool
  default     = true
}

variable "tags" {
  description = "Additional tags for resources"
  type        = map(string)
  default     = {}
}

#------------------------------------------------------------------------------
# VPC Configuration for Lambda
#------------------------------------------------------------------------------
variable "vpc_id" {
  description = "VPC ID for Lambda function (optional, enables VPC mode)"
  type        = string
  default     = ""
}

variable "lambda_subnet_ids" {
  description = "Subnet IDs for Lambda function (required if vpc_id is set)"
  type        = list(string)
  default     = []
}

variable "kms_key_arn" {
  description = "KMS key ARN for encrypting Lambda environment variables"
  type        = string
  default     = ""
}
