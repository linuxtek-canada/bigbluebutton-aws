locals {
  name_prefix = "${var.project_name}-${var.environment}"

  common_tags = {
    Project     = var.project_name
    Environment = var.environment
    Component   = "admin-dashboard"
  }

  # CORS allowed origin - use custom domain if provided, otherwise CloudFront domain
  cors_allowed_origin = var.domain_name != "" ? "https://${var.domain_name}" : "https://${aws_cloudfront_distribution.admin.domain_name}"
}
