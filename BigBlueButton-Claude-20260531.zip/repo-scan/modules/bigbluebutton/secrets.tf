#------------------------------------------------------------------------------
# AWS Secrets Manager for Sensitive Configuration
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
# BigBlueButton Admin Password Secret
#------------------------------------------------------------------------------
resource "aws_secretsmanager_secret" "bbb_admin_password" {
  count = var.bbb_admin_password != "" ? 1 : 0

  name        = "${local.name_prefix}/bbb-admin-password"
  description = "BigBlueButton admin password"
  kms_key_id  = var.enable_kms ? aws_kms_key.main[0].arn : null

  tags = {
    Name        = "${local.name_prefix}-bbb-admin-password"
    Project     = var.project_name
    Environment = var.environment
  }
}

resource "aws_secretsmanager_secret_version" "bbb_admin_password" {
  count = var.bbb_admin_password != "" ? 1 : 0

  secret_id     = aws_secretsmanager_secret.bbb_admin_password[0].id
  secret_string = var.bbb_admin_password
}

#------------------------------------------------------------------------------
# Output for Ansible to retrieve the secret
#------------------------------------------------------------------------------
output "bbb_admin_password_secret_arn" {
  description = "ARN of the Secrets Manager secret containing the admin password"
  value       = var.bbb_admin_password != "" ? aws_secretsmanager_secret.bbb_admin_password[0].arn : ""
  sensitive   = true
}
